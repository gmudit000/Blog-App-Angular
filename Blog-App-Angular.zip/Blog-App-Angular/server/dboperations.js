const config = require("./dbConfig");
const sql = require("mssql/msnodesqlv8");

async function getBlogs(){
    try{
        let pool = await sql.connect(config);
        let data = await pool.request().query("Select * from Blog");
        return data.recordsets;
    }
    catch(error){
        console.log(error);
    }
}

async function getBlogsAtId(BlogId){
    try{
        let pool = await sql.connect(config);
        let data = await pool.request()
            .input('input_parameter', sql.Int, BlogId)
            .query("Select * from Blog where BlogId = @input_parameter");
        return data.recordsets;
    }
    catch(error){
        console.log(error);
    }
}

async function addBlog(blog){
    try{
        let pool = await sql.connect(config);
        let data = await pool.request()
            .input('Title', sql.VarChar, blog.Title)
            .input('Categories', sql.VarChar,blog.Categories)
            .input('Content', sql.VarChar, blog.Content)
            .query("INSERT INTO Blog (Title, Categories, Content) VALUES (@Title,@Categories,@Content)")
        return data.recordsets;
    }catch(error){
        console.log(error)
    }
}

async function deleteBlog(BlogId){
    try{
        let pool = await sql.connect(config);
        let data = await pool.request()
            .input('input_parameter', sql.Int, BlogId)
            .query("DELETE FROM Blog WHERE BlogId = @input_parameter")
        return data.recordsets;
    }catch(error){
        console.log(error)
    }
}

async function updateBlog(BlogId,blog){
    try{
        let pool = await sql.connect(config);
        let data = await pool.request()
            .input('BlogId', sql.Int, BlogId)
            .input('Title', sql.VarChar, blog.Title)
            .input('Categories', sql.VarChar,blog.Categories)
            .input('Content', sql.VarChar, blog.Content)
            .query("Update Blog SET Title = @Title, Categories=@Categories, content = @Content WHERE BlogId = @BlogId")
        return data.recordsets;
    }catch(error){
        console.log(error)
    }
}

module.exports = {
    getBlogs : getBlogs,
    getBlogsAtId : getBlogsAtId,
    addBlog : addBlog,
    deleteBlog : deleteBlog,
    updateBlog : updateBlog
}