const express = require('express');
const router = express.Router();
const dboperations = require('../dboperations');
const Blog = require('../model/blog');

// list all blogs
router.route('/list').get((req,res) => {
    let blogList;
    dboperations.getBlogs().then(result => {
        blogList = result[0];
        res.send(blogList); 
    })
})

// add blog - new blog
router.route('/add').post((req,res) => {
    let blog = {
        Title: req.body.Title,
        Categories: req.body.Categories,
        Content: req.body.Content
    }
    dboperations.addBlog(blog).then(result => {
        console.log('Blog Added')
    });
})

// view blog
router.route('/view/:Id').get((req,res) => {
    let blogAtId;
    dboperations.getBlogsAtId(req.params.Id).then(result => {
        blogAtId = result[0];
        res.send(blogAtId);
      })
})

// edit blog
router.route('/edit/:Id').put((req,res) => {
    let blog = {
        Title: req.body.Title,
        Categories: req.body.Categories,
        Content: req.body.Content
    }
    dboperations.updateBlog(req.params.Id,blog).then(result => {
        console.log('Blog Updated');
    })
})

// delete blog
router.route('/delete/:Id').delete((req,res) => {
    dboperations.deleteBlog(req.params.Id).then(result => {
        console.log('Blog Deleted');
    })
})

module.exports = router;