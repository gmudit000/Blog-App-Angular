const express = require('express');
const port = 5000;
const app = express();
const blogRouter = require('./routes/blogs');
const cors = require('cors');
app.use(cors());

// middleware for data parsing from forms
app.use(express.urlencoded({extended: false}));
app.use(express.json());

// all blog operations api
app.use('/api/blogs',blogRouter);

app.listen(port, () => {
    console.log(`Blog App listening at http://localhost:${port}`);
})