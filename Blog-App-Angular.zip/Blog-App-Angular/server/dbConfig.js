const dbConfig = {
    server: "MUDITGARG",
    port: 1433,
    database: "BlogAppDb",
    options: {
      trustedConnection: true,
    }
  }  

  module.exports = dbConfig