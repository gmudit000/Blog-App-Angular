class Blog{
    constructor(BlogId, Title, Categories, Content){
        this.BlogId = BlogId;
        this.Title = Title;
        this.Categories = Categories;
        this.Content = Content;
    }
}

module.exports = Blog;