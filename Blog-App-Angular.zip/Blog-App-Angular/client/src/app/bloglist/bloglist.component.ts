import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { IBlog } from '../blog';
import { blogDataService } from './../blogData.service';

@Component({
  templateUrl: './bloglist.component.html'
})
export class BloglistComponent implements OnInit,OnDestroy {
  blogList: IBlog[] = [];
  errorMessage: string = 'Error Message';
  sub!: Subscription;

  constructor(private blogDataService: blogDataService) { }

  ngOnInit(): void {
    this.sub = this.blogDataService.getBlogList().subscribe({
      next: blogList => this.blogList = blogList,
      error: err => this.errorMessage = err
    })
  }

  ngOnDestroy() : void{
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}