import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { IBlog } from '../blog';
import { blogDataService } from './../blogData.service';

@Component({
  templateUrl: './blogview.component.html'
})
export class BlogviewComponent implements OnInit {
  blogAtId: IBlog[] = [];
  errorMessage: string = 'Error Message';
  sub!: Subscription;
  Id!: number; 
  
  constructor(private blogDataService : blogDataService,
              private route : ActivatedRoute,
              private router : Router) { }

  ngOnInit(): void {
    this.Id = Number(this.route.snapshot.paramMap.get('Id'));

    this.sub = this.blogDataService.getBlogAtId(this.Id).subscribe({
      next: blogAtId => this.blogAtId = blogAtId,
      error: err => this.errorMessage = err
    })
  }

  onBack() : void{
    this.router.navigate(['/home']);
  }

  deleteHandler() : void{
    this.sub = this.blogDataService.deleteBlog(this.Id).subscribe({
      error: err => this.errorMessage = err
    })
    this.onBack();
  }

  ngOnDestroy() : void{
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}