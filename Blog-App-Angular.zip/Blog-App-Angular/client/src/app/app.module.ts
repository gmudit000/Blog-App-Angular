import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { BloglistComponent } from './bloglist/bloglist.component';
import { BlogviewComponent } from './blogview/blogview.component';
import { BlogupdateComponent } from './blogupdate/blogupdate.component';
import { BlogcreateComponent } from './blogcreate/blogcreate.component';

@NgModule({
  declarations: [
    AppComponent,
    BloglistComponent,
    BlogviewComponent,
    BlogcreateComponent,
    BlogupdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'home', component: BloglistComponent},
      {path: 'view/:Id', component: BlogviewComponent},
      {path: 'create', component: BlogcreateComponent},
      {path: 'edit/:Id', component: BlogupdateComponent},
      {path: '', redirectTo:'home', pathMatch: 'full'}, // default route
      {path: '**', redirectTo:'home',pathMatch: 'full'} // wildcard route
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }