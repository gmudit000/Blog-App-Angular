import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { IBlog } from '../blog';
import { blogDataService } from '../blogData.service';

@Component({
  templateUrl: './blogupdate.component.html'
})
export class BlogupdateComponent implements OnInit {
  updatedData: IBlog[] = [];
  blogAtId: IBlog[] = [];
  sub!: Subscription;
  errorMessage: string = 'Error Message';
  Id!: number;
  
  constructor(private blogDataService: blogDataService, 
              private router : Router,
              private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.Id = Number(this.route.snapshot.paramMap.get('Id'));

    this.sub = this.blogDataService.getBlogAtId(this.Id).subscribe({
      next: blogAtId => this.blogAtId = blogAtId,
      error: err => this.errorMessage = err
    })
  }

  onSubmit(updatedData: IBlog) : void{
    this.sub = this.blogDataService.updateBlog(updatedData, this.Id).subscribe({
      next: updatedData => this.updatedData = updatedData,
      error: err => this.errorMessage = err
    })
    this.onBack();
  }

  onBack() : void{
    this.router.navigate([`/view/${this.Id}`]);
  }
  
  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}