export interface IBlog {
    BlogId: number;
    Title: string;
    Categories: string;
    Content: string;
}