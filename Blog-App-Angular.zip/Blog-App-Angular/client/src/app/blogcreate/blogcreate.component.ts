import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { IBlog } from '../blog';
import { blogDataService } from '../blogData.service';

@Component({
  templateUrl: './blogcreate.component.html'
})
export class BlogcreateComponent implements OnInit {
  data: IBlog[] = [];
  sub!: Subscription;
  errorMessage: string = 'Error Message';

  constructor(private blogDataService: blogDataService, private router : Router) { }

  ngOnInit(): void{
  }

  onSubmit(data: IBlog) : void{
    this.sub = this.blogDataService.postNewBlog(data).subscribe({
      next: data => this.data = data,
      error: err => this.errorMessage = err
    })
    this.onBack();
  }

  onBack() : void{
    this.router.navigate(['/home']);
  }
  
  ngOnDestroy(): void {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}