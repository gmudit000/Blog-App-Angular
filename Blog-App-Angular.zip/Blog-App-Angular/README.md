## Blog App Angular

To Run the app
Start the backend server: cd server > npm install > npm run dev
Run the Blog App: cd client > npm install > npm start

Server folder contains the backend code
    - It contains all the Node.js backend code

    dbConfig.js file - contains the configuration of SQL server database which provides database for Blog App

    dboperations.js file - contains functions (Sql queries that are performed on database) 
                         - server interacting with database

    server.js file - contain express app instance, middlewares, cors, port no and blogRouter
    
    routes/blog.js file - contains all the Api endpoints to
        -Create blog
        -Update blog
        -Get blog list
        -Get blog at particular id
        -Delete blog at particular id

    model/blog.js file - model of blog 
    

Client folder contains the frontend code
    - It contains all the Angular frontend code

    - It contain 5 Components
        - 1 root component - app
        - 4 blog components - blogcreate, bloglist, blogupdate, blogview

    blog.ts - It is a interface for the blog, used as datatype while interacting with blog data

    blogData.service.ts - It is a blog data service which contains function to get data from backend with the help of httpClient

        5 functions:
        - getBlogList
        - getBlogAtId
        - postNewBlog
        - updateBlog
        - deleteBlog

    blogData service is injected into the components to use specific functions to get/post/put/delete data.

    app.module.ts - contains all the necessary imports and routes for app
        
    Routes: 
      {path: 'home', component: BloglistComponent},
      {path: 'view/:Id', component: BlogviewComponent},
      {path: 'create', component: BlogcreateComponent},
      {path: 'edit/:Id', component: BlogupdateComponent},
      {path: '', redirectTo:'home', pathMatch: 'full'}, // default route
      {path: '**', redirectTo:'home',pathMatch: 'full'} // wildcard route